<div id="header">
		
		<ul>
			<li><a href="index.php">Home</a></li>
            <li><a href="User.php">User</a></li>
			<li><a href="Category.php">Category</a></li>
			<li><a href="Subject.php">Subject</a></li>
			<li><a href="Faculty.php">Faculty</a></li>
			<li><a href="Student.php">Student</a></li>
			<li><a href="Logout.php">Logout</a></li>
		</ul>
	</div>
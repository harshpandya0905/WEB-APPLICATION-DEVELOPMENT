<div id="header">
		
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="Profile.php">Profile</a></li>
            <li><a href="Student.php">Student</a></li>
			<li><a href="Schedule.php">Schedule</a></li>
			<li><a href="Question.php">Question</a></li>
          
			<li><a href="Logout.php">Logout</a></li>
		</ul>
	</div>
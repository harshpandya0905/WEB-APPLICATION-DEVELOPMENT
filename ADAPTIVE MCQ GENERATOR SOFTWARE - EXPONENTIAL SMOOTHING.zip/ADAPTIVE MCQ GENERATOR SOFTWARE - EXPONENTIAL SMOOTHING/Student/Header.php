<div id="header">
		
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="Profile.php">Profile</a></li>
			<li><a href="StartExam.php">Exam</a></li>
			<li><a href="Result.php">Result</a></li>

			<li><a href="Logout.php">Logout</a></li>
		</ul>
	</div>